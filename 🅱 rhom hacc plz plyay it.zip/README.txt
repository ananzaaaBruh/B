Hey, thanks for downloading my rom hack!
I really worked on it, I hope you guys enjoyed!
For playing the game you need these programs:
Snes9x (SNES Emulator)
Flips (SNES Rom Hack Patcher)
And thats it!
Links:
https://www.emulator-zone.com/snes/snes9x --Snes9x
https://dl.smwcentral.net/11474/floating.zip --Flips
Have fun!
The programs I used while making this rom hack is:
Lunar Magic
yychr
You can found these programs in https://www.smwcentral.net/ !







And!..........
im out of ideas plz hlep if u hlep tysm then u think maybe im gana put u in the credites if ur hlep and me is do!!!!11111
credits lol:
myself
my few frends lol
myself again
the ᵇᵘˢᵗᵉʳ

















































































































edit: maro is lot more thicc then before!!!!!!111111 and!11
maro becom scare when he thicc
maro is becom E and b when hes move!!!111 yaya